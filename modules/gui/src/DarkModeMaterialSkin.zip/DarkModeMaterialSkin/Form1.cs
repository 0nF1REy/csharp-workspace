using MaterialSkin;
using MaterialSkin.Controls;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace DarkModeMaterialSkin
{
    public partial class frmPrincipal : MaterialForm
    {
        private readonly MaterialSkinManager materialSkinManager;

        public frmPrincipal()
        {
            InitializeComponent();

            materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this); 

            DarkMode = Properties.Settings.Default.DarkMode;
            ApplyMaterialTheme(DarkMode);

            this.FormClosing += (s, e) =>
            {
                if (MessageBox.Show("Deseja realmente sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    e.Cancel = true;
                }
            };
        }

        private bool DarkMode
        {
            get { return materialSkinManager.Theme == MaterialSkinManager.Themes.DARK; }
            set
            {
                materialSkinManager.Theme = value ? MaterialSkinManager.Themes.DARK : MaterialSkinManager.Themes.LIGHT;
                this.Text = value ? "Modo Escuro" : "Modo Claro";
            }
        }

        private void btnSwitch_Click(object sender, EventArgs e)
        {
            DarkMode = !DarkMode;

            Properties.Settings.Default.DarkMode = DarkMode;
            Properties.Settings.Default.Save();
        }

        private void ApplyMaterialTheme(bool darkMode)
        {
            materialSkinManager.Theme = darkMode ? MaterialSkinManager.Themes.DARK : MaterialSkinManager.Themes.LIGHT;

            if (darkMode)
            {
                materialSkinManager.ColorScheme = new ColorScheme(
                    Primary.BlueGrey900, Primary.BlueGrey800, Primary.BlueGrey500,
                    Accent.LightBlue200, TextShade.WHITE
                );
            }
            else
            {
                materialSkinManager.ColorScheme = new ColorScheme(
                    Primary.Indigo500, Primary.Indigo700, Primary.Indigo100,
                    Accent.Pink200, TextShade.WHITE
                );
            }
        }
    }
}