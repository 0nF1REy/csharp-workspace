﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using CONTROLE_ACADEMIA.modelo;
using System.Drawing;
using System.Data.SqlClient;

namespace CONTROLE_ACADEMIA.controle
{
    public class AlunoDB
    {
        ServidorSQL server = new ServidorSQL();
        public string Insert(Aluno Reg)
        {
            try
            {
                string sql = $"INSERT INTO ALUNO VALUES(" +
                    $"{Reg.ID}," +
                    $"'{Reg.Nome}'," +
                    $"'{Reg.Nascimento.Date}'," +
                    $"'{Reg.Contato}'," +
                    $"'{Reg.Documento}'," +
                    $"{Reg.Peso.ToString().Replace(',', '.')}," +
                    $"{Reg.Altura.ToString().Replace(',', '.')}," +
                    $"'{Reg.Sexo}')";

                server.Open("academia.sqlite"); // Abre o banco de dados

                using (SQLiteCommand cmd = new SQLiteCommand(server.Connection))
                {
                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                return $"FAIL: {ex.Message}";
            }
            return "OK";
        }

        public string Select(List<Aluno> Lista)
        {
            try
            {
                string sql = "SELECT * FROM ALUNO ORDER BY COD";

                server.Open("academia.sqlite");

                using (SQLiteCommand cmd = new SQLiteCommand(server.Connection))
                {
                    cmd.CommandText = sql;
                    SQLiteDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        Aluno reg = new Aluno()
                        {
                            ID = dr.GetInt32(0),
                            Nome = dr.GetString(1),
                            Nascimento = Convert.ToDateTime(dr.GetString(2)),
                            Contato = dr.GetString(3),
                            Documento = dr.GetString(4),
                            Peso = dr.GetDouble(5),
                            Altura = dr.GetDouble(6),
                            Sexo = dr.GetString(7)
                        };
                        Lista.Add(reg);
                    }
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                return $"FAIL: {ex.Message}";
            }
            return "OK";
        }

        public string Delete(Aluno Reg)
        {
            try
            {
                string sql = $"DELETE FROM ALUNO WHERE COD = {Reg.ID}";

                server.Open("academia.sqlite");

                using (SQLiteCommand cmd = new SQLiteCommand(server.Connection))
                {
                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                return $"FAIL: {ex.Message}";
            }
            return "OK";
        }

        public string Update(Aluno reg)
        {
            try
            {
                string sql = $"UPDATE ALUNO SET " +
                    $"NOME = '{reg.Nome}'," +
                    $"NASCIMENTO = '{reg.Nascimento.Date}'," +
                    $"DOCUMENTO = '{reg.Documento}'," +
                    $"PESO = {reg.Peso.ToString().Replace(',', '.')}," +
                    $"ALTURA = {reg.Altura.ToString().Replace(',', '.')}," +
                    $"SEXO = '{reg.Sexo}' " +
                    $"WHERE COD = {reg.ID}";


                server.Open("academia.sqlite");

                using (SQLiteCommand cmd = new SQLiteCommand(
                    server.Connection))
                {
                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                return $"FAIL: {ex.Message}";
            }
            return "OK";
        }
    }
}