﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CONTROLE_ACADEMIA.controle
{
    public class ServidorSQL
    {
        public SQLiteConnection Connection { get; set; }

        public ServidorSQL()
        {
            Connection = new SQLiteConnection();
        }
        public string CreateDatabase(string name)
        {
            try
            {
                SQLiteConnection.CreateFile(name);
            } catch (Exception ex)
            {
                return $"FAIL: {ex.Message}";
            }
            return "OK";
        }
        public void Open (string name)
        {
            string str = $"Data Source = {name};version=3;";
            Connection.ConnectionString = str;
            Connection.Open();
        }
        public string CreateTable(string sql, string db)
        {
            try
            {
                Open(db); // Abre o banco de dados

                using (SQLiteCommand cmd = new SQLiteCommand(Connection))
                {
                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                return $"FAIL: {ex.Message}";
            }
            return "OK";
        } 
    }
}
