﻿using CONTROLE_ACADEMIA.controle;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CONTROLE_ACADEMIA.modelo
{
    public class Academia
    {
        public List<Aluno> Alunos { get; set; }

        public Academia()
        {
            Alunos = new List<Aluno>();
        }

        public void Matricular(Aluno Reg)
        {
            AlunoDB table = new AlunoDB();

            try
            {
                string res = table.Insert(Reg);
                if (res == "OK") Alunos.Add(Reg); // Matricular o aluno
                else
                {
                    System.Windows.Forms.MessageBox.Show(
                    $"Erro:{res}");
                    Environment.Exit(0); // Sai do programa
                }
            }
            catch (Exception Erro)
            {
                System.Windows.Forms.MessageBox.Show(
                    $"Erro:{Erro.Message}");
            }
        }
        public void Update(Aluno Reg)
        {
            try
            {
                Aluno old = Alunos.FirstOrDefault(
                    i => i.ID == Reg.ID
                    );
                if (old != null)
                {
                    old.Nome = Reg.Nome;
                    old.Contato = Reg.Contato;
                    old.Altura = Reg.Altura;
                    old.Peso = Reg.Peso;
                    old.Sexo = Reg.Sexo;
                    old.Documento = Reg.Documento;
                    old.Nascimento = Reg.Nascimento;
                }
            }
            catch (Exception Erro)
            {
                System.Windows.Forms.MessageBox.Show(
                    $"Erro:{Erro.Message}");
            }
        }
        public void Delete(Aluno Reg)
        {
            try
            {
                Aluno old = Alunos.FirstOrDefault(
                    i => i.ID == Reg.ID
                    );
                if (old != null)
                {
                    AlunoDB table = new AlunoDB();
                    string res = table.Delete(old);
                    Alunos.Remove(old);
                }
            }
            catch (Exception Erro)
            {
                System.Windows.Forms.MessageBox.Show(
                    $"Erro:{Erro.Message}");
            }
        }
        public void Editar(Aluno reg)
        {
            try
            {
                Aluno old = Alunos.FirstOrDefault(i => i.ID == reg.ID);
                old.Nome = reg.Nome;
                old.Contato = reg.Contato;
                old.Altura = reg.Altura;
                old.Peso = reg.Peso;
                old.Sexo = reg.Sexo;
                old.Documento = reg.Documento;
                old.Nascimento = reg.Nascimento;

                AlunoDB tabela = new AlunoDB();
                string res = tabela.Update(old);
                if (res != "OK")
                {
                    MessageBox.Show($"Erro:{res}");
                    Environment.Exit(0); // Sai do programa
                }
            }
            catch (Exception Erro)
            {
                MessageBox.Show(Erro.Message);

            }
        }
    }
}