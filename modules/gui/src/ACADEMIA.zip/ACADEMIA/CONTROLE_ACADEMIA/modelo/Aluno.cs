﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CONTROLE_ACADEMIA.modelo
{
    public class Aluno
    {
        public Int32 ID { get; set; }
        public string Nome { get; set; }
        public DateTime Nascimento { get; set; }
        public string Documento { get; set; }
        public string Contato { get; set; }
        public double Peso { get; set; }
        public double Altura { get; set; }
        public string Sexo { get; set; }

        public Aluno(Int32 ID, string Nome, DateTime Nascimento,
           string Documento, string Contato, double Peso,
           double Altura, string Sexo)
        {
            this.ID = ID;
            this.Nome = Nome;
            this.Documento = Documento;
            this.Nascimento = Nascimento;
            this.Contato = Contato;
            this.Peso = Peso;
            this.Altura = Altura;
            this.Sexo = Sexo;
        }

        public Aluno(): this(0,"",DateTime.Now,"","",0,0,"")
        {

        }

        public double IMC
        {
            get { return Math.Round(Peso / Math.Pow(Altura, 2), 2); }
        }

        public int Idade
        {
            get
            {
                TimeSpan calculo = DateTime.Now - Nascimento;
                int i = (int)Math.Truncate(calculo.TotalDays/365);
                return i;
            }
        }

    }
}
