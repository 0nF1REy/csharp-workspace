﻿namespace CONTROLE_ACADEMIA.visao
{
    partial class FormWebCam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.CbDevices = new System.Windows.Forms.ComboBox();
            this.BtnStart = new System.Windows.Forms.Button();
            this.BtnFoto = new System.Windows.Forms.Button();
            this.BtnSalvar = new System.Windows.Forms.Button();
            this.PbFoto = new System.Windows.Forms.PictureBox();
            this.PbVideo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PbFoto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbVideo)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(226, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "LISTA DE CAMERAS DISPONIVEIS";
            // 
            // CbDevices
            // 
            this.CbDevices.BackColor = System.Drawing.Color.SeaShell;
            this.CbDevices.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CbDevices.FormattingEnabled = true;
            this.CbDevices.Location = new System.Drawing.Point(12, 52);
            this.CbDevices.Name = "CbDevices";
            this.CbDevices.Size = new System.Drawing.Size(313, 32);
            this.CbDevices.TabIndex = 1;
            // 
            // BtnStart
            // 
            this.BtnStart.BackColor = System.Drawing.Color.IndianRed;
            this.BtnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnStart.ForeColor = System.Drawing.Color.White;
            this.BtnStart.Location = new System.Drawing.Point(12, 99);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(313, 54);
            this.BtnStart.TabIndex = 2;
            this.BtnStart.Text = "INICIAR CAMERA DE VIDEO";
            this.BtnStart.UseVisualStyleBackColor = false;
            this.BtnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // BtnFoto
            // 
            this.BtnFoto.BackColor = System.Drawing.Color.IndianRed;
            this.BtnFoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFoto.ForeColor = System.Drawing.Color.White;
            this.BtnFoto.Location = new System.Drawing.Point(12, 410);
            this.BtnFoto.Name = "BtnFoto";
            this.BtnFoto.Size = new System.Drawing.Size(146, 54);
            this.BtnFoto.TabIndex = 5;
            this.BtnFoto.Text = "CAPTURAR";
            this.BtnFoto.UseVisualStyleBackColor = false;
            this.BtnFoto.Click += new System.EventHandler(this.BtnFoto_Click);
            // 
            // BtnSalvar
            // 
            this.BtnSalvar.BackColor = System.Drawing.Color.IndianRed;
            this.BtnSalvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSalvar.ForeColor = System.Drawing.Color.White;
            this.BtnSalvar.Location = new System.Drawing.Point(179, 410);
            this.BtnSalvar.Name = "BtnSalvar";
            this.BtnSalvar.Size = new System.Drawing.Size(146, 54);
            this.BtnSalvar.TabIndex = 6;
            this.BtnSalvar.Text = "SALVAR FOTO";
            this.BtnSalvar.UseVisualStyleBackColor = false;
            this.BtnSalvar.Click += new System.EventHandler(this.BtnSalvar_Click);
            // 
            // PbFoto
            // 
            this.PbFoto.BackColor = System.Drawing.Color.Gainsboro;
            this.PbFoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbFoto.Location = new System.Drawing.Point(179, 171);
            this.PbFoto.Name = "PbFoto";
            this.PbFoto.Size = new System.Drawing.Size(146, 223);
            this.PbFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbFoto.TabIndex = 4;
            this.PbFoto.TabStop = false;
            // 
            // PbVideo
            // 
            this.PbVideo.BackColor = System.Drawing.Color.Gainsboro;
            this.PbVideo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbVideo.Location = new System.Drawing.Point(12, 171);
            this.PbVideo.Name = "PbVideo";
            this.PbVideo.Size = new System.Drawing.Size(146, 223);
            this.PbVideo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbVideo.TabIndex = 3;
            this.PbVideo.TabStop = false;
            // 
            // FormWebCam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(341, 476);
            this.Controls.Add(this.BtnSalvar);
            this.Controls.Add(this.BtnFoto);
            this.Controls.Add(this.PbFoto);
            this.Controls.Add(this.PbVideo);
            this.Controls.Add(this.BtnStart);
            this.Controls.Add(this.CbDevices);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormWebCam";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CAPTURA CAMERA WEB";
            this.Load += new System.EventHandler(this.FormWebCam_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PbFoto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbVideo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CbDevices;
        private System.Windows.Forms.Button BtnStart;
        private System.Windows.Forms.PictureBox PbVideo;
        private System.Windows.Forms.PictureBox PbFoto;
        private System.Windows.Forms.Button BtnFoto;
        private System.Windows.Forms.Button BtnSalvar;
    }
}