﻿using CONTROLE_ACADEMIA.controle;
using CONTROLE_ACADEMIA.modelo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CONTROLE_ACADEMIA.visao
{
    public partial class FormAcademia : Form
    {
        public FormAcademia()
        {
            InitializeComponent();
        }

        Academia LylieGym;
        BindingSource bs;

        private void FormAcademia_Load(object sender, EventArgs e)
        {
            LylieGym = new Academia();
            bs = new BindingSource();
            CreateDataBase(); // Criar o banco de dados
            PreencherDados();
            if(LylieGym.Alunos.Count == 0)
            {
                AlunoDB table = new AlunoDB();
                string res = table.Select(LylieGym.Alunos);
                if (res != "OK")
                {
                    MessageBox.Show($"Erro: {res}");
                }
            }
            bs.DataSource = LylieGym.Alunos;
            Dg.DataSource = bs;
            Bn.BindingSource = bs; // Vincula a barra de navegação
            Dg.AutoResizeColumns(); // Dimensionamento automático das colunas
            Dg.Columns["Documento"].Visible = false;
            Dg.Columns["Nascimento"].Visible = false;
            Dg.DefaultCellStyle.ForeColor = Color.FromArgb(3, 57, 108);
            Dg.DefaultCellStyle.BackColor = Color.FromArgb(179, 205, 224);
        }

        private void CreateDataBase()
        {
            string db = "academia.sqlite";
            if(!File.Exists(db))
            {
                ServidorSQL server = new ServidorSQL();
                if (server.CreateDatabase(db) == "OK") 
                MessageBox.Show("Academia.sqlite criado com " +
                    "sucesso");
                CriarTabelaAluno();
            }
        }

        private void CriarTabelaAluno()
        {
            string sql = "CREATE TABLE IF NOT EXISTS ALUNO(" +
                "COD INT PRIMARY KEY," +
                "NOME VARCHAR(30)," +
                "NASCIMENTO DATE," +
                "CONTATO VARCHAR(15)," +
                "DOCUMENTO VARCHAR(15)," +
                "PESO DOUBLE," +
                "ALTURA DOUBLE," +
                "SEXO VARCHAR(1)" +
                ")";

            ServidorSQL server = new ServidorSQL();

            if (server.CreateTable(sql, "academia.sqlite") == "OK")
            {
                MessageBox.Show("Tabela aluno criado com " +
                    "sucesso");
            } else
            {
                MessageBox.Show("Erro ao criar tabela" + "sucesso");
            }

        }

        private void PreencherDados()
        {
            string fileData = "lista_clientes.txt";
            if (File.Exists(fileData))
            {
                StreamReader sr = new StreamReader(fileData);
                while (sr.Peek() != -1)
                {
                    string line = sr.ReadLine();
                    Aluno Reg = new Aluno()
                    {
                        ID = Int16.Parse(line.Split(',')[0]),
                        Nome = line.Split(',')[1],
                        Nascimento = new DateTime(
                            Int16.Parse(line.Split(',')[2]
                            .Substring(0,4)),
                            Int16.Parse(line.Split(',')[2]
                            .Substring(5,2)),
                            Int16.Parse(line.Split(',')[2]
                            .Substring(8, 2))
                            ),
                        Documento = line.Split(',')[3],
                        Contato = line.Split(',')[4],
                        Peso = Double.Parse(line.Split(',')[5]
                        .Replace('.',',')),
                        Altura = Double.Parse(line.Split(',')[6]
                        .Replace('.', ',')),
                        Sexo = line.Split(',')[7]
                    };
                    LylieGym.Matricular(Reg);
                }
                sr.Close();
            }
        }

        private void BtnMatricular_Click(object sender, EventArgs e)
        {
            FormMatricula matricula = new FormMatricula();
            matricula.Reg = null;
            matricula.ShowDialog();
            if(matricula.Reg != null)
            {
                LylieGym.Matricular(matricula.Reg);
                bs.ResetBindings(true);
                bs.MoveLast();
            }
        }

        private void BtnRemover_Click(object sender, EventArgs e)
        {
            Aluno Reg = (Aluno)bs.Current;

            DialogResult op =
                MessageBox.Show($"Deseja Remover aluno(a) " +
                $"{Reg.Nome}", "ALERTA",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (op == DialogResult.Yes)
            {
                LylieGym.Delete(Reg);
                bs.ResetBindings(true);
                bs.MoveLast();
            }
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            FormMatricula ficha = new FormMatricula();
            ficha.Reg = (Aluno)bs.Current;
            if(PbFoto.Image != null)
            {
                Application.DoEvents();
                PbFoto.Image.Dispose();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            ficha.ShowDialog();
            if (ficha.Reg != null)
            {
                LylieGym.Editar(ficha.Reg);
                bs.ResetBindings(true);
                Dg.AutoResizeColumns();
                CarregarFoto();
            }
        }

        private void Dg_SelectionChanged(object sender, EventArgs e)
        {
            CarregarFoto();
        }

        private void CarregarFoto()
        {
            Aluno reg = (Aluno)bs.Current;
            string caminho = $"\\fotos\\{reg.ID}.png";
            if (File.Exists(Environment.CurrentDirectory +
             caminho))
            {
                var fs = new FileStream(Environment.CurrentDirectory +
                caminho, FileMode.Open, FileAccess.Read);

                PbFoto.Image = Image.FromStream(fs);

                LbNome.Text = reg.Nome;
            }
            else
            {
                LbNome.Text = reg.Nome;
                PbFoto.Image = null;
            }
        }
    }
}
