﻿namespace CONTROLE_ACADEMIA.visao
{
    partial class FormMatricula
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PnLateral = new System.Windows.Forms.Panel();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnGravar = new System.Windows.Forms.Button();
            this.BtnWebCam = new System.Windows.Forms.Button();
            this.BtnFoto = new System.Windows.Forms.Button();
            this.PbFoto = new System.Windows.Forms.PictureBox();
            this.PnFicha = new System.Windows.Forms.Panel();
            this.CbSexo = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TxtAltura = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TxtPeso = new System.Windows.Forms.MaskedTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TxtContato = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TxtDocumento = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.DtNascimento = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtMatricula = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.PnLateral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbFoto)).BeginInit();
            this.PnFicha.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnLateral
            // 
            this.PnLateral.BackgroundImage = global::CONTROLE_ACADEMIA.Properties.Resources.bg;
            this.PnLateral.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnLateral.Controls.Add(this.BtnCancelar);
            this.PnLateral.Controls.Add(this.BtnGravar);
            this.PnLateral.Controls.Add(this.BtnWebCam);
            this.PnLateral.Controls.Add(this.BtnFoto);
            this.PnLateral.Controls.Add(this.PbFoto);
            this.PnLateral.Dock = System.Windows.Forms.DockStyle.Left;
            this.PnLateral.Location = new System.Drawing.Point(0, 0);
            this.PnLateral.Name = "PnLateral";
            this.PnLateral.Size = new System.Drawing.Size(250, 477);
            this.PnLateral.TabIndex = 0;
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCancelar.Location = new System.Drawing.Point(3, 410);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(242, 54);
            this.BtnCancelar.TabIndex = 12;
            this.BtnCancelar.Text = "CANCELAR";
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // BtnGravar
            // 
            this.BtnGravar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnGravar.Location = new System.Drawing.Point(3, 344);
            this.BtnGravar.Name = "BtnGravar";
            this.BtnGravar.Size = new System.Drawing.Size(242, 54);
            this.BtnGravar.TabIndex = 11;
            this.BtnGravar.Text = "GRAVAR FICHA";
            this.BtnGravar.UseVisualStyleBackColor = true;
            this.BtnGravar.Click += new System.EventHandler(this.BtnGravar_Click);
            // 
            // BtnWebCam
            // 
            this.BtnWebCam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnWebCam.Location = new System.Drawing.Point(3, 280);
            this.BtnWebCam.Name = "BtnWebCam";
            this.BtnWebCam.Size = new System.Drawing.Size(242, 54);
            this.BtnWebCam.TabIndex = 10;
            this.BtnWebCam.Text = "WEBCAM";
            this.BtnWebCam.UseVisualStyleBackColor = true;
            this.BtnWebCam.Click += new System.EventHandler(this.BtnWebCam_Click);
            // 
            // BtnFoto
            // 
            this.BtnFoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFoto.Location = new System.Drawing.Point(3, 217);
            this.BtnFoto.Name = "BtnFoto";
            this.BtnFoto.Size = new System.Drawing.Size(242, 54);
            this.BtnFoto.TabIndex = 9;
            this.BtnFoto.Text = "FOTO";
            this.BtnFoto.UseVisualStyleBackColor = true;
            this.BtnFoto.Click += new System.EventHandler(this.BtnFoto_Click);
            // 
            // PbFoto
            // 
            this.PbFoto.BackColor = System.Drawing.Color.LightSteelBlue;
            this.PbFoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbFoto.Location = new System.Drawing.Point(3, 3);
            this.PbFoto.Name = "PbFoto";
            this.PbFoto.Size = new System.Drawing.Size(242, 200);
            this.PbFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbFoto.TabIndex = 0;
            this.PbFoto.TabStop = false;
            // 
            // PnFicha
            // 
            this.PnFicha.BackColor = System.Drawing.Color.LightSteelBlue;
            this.PnFicha.BackgroundImage = global::CONTROLE_ACADEMIA.Properties.Resources.bg;
            this.PnFicha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnFicha.Controls.Add(this.CbSexo);
            this.PnFicha.Controls.Add(this.label8);
            this.PnFicha.Controls.Add(this.TxtAltura);
            this.PnFicha.Controls.Add(this.label7);
            this.PnFicha.Controls.Add(this.TxtPeso);
            this.PnFicha.Controls.Add(this.label6);
            this.PnFicha.Controls.Add(this.TxtContato);
            this.PnFicha.Controls.Add(this.label5);
            this.PnFicha.Controls.Add(this.TxtDocumento);
            this.PnFicha.Controls.Add(this.label4);
            this.PnFicha.Controls.Add(this.DtNascimento);
            this.PnFicha.Controls.Add(this.label3);
            this.PnFicha.Controls.Add(this.TxtNome);
            this.PnFicha.Controls.Add(this.label2);
            this.PnFicha.Controls.Add(this.TxtMatricula);
            this.PnFicha.Controls.Add(this.label1);
            this.PnFicha.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnFicha.Location = new System.Drawing.Point(250, 0);
            this.PnFicha.Name = "PnFicha";
            this.PnFicha.Size = new System.Drawing.Size(550, 477);
            this.PnFicha.TabIndex = 1;
            // 
            // CbSexo
            // 
            this.CbSexo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbSexo.FormattingEnabled = true;
            this.CbSexo.Items.AddRange(new object[] {
            "Masculino",
            "Feminino",
            "Indefinido"});
            this.CbSexo.Location = new System.Drawing.Point(18, 444);
            this.CbSexo.Name = "CbSexo";
            this.CbSexo.Size = new System.Drawing.Size(518, 21);
            this.CbSexo.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(15, 423);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 18);
            this.label8.TabIndex = 14;
            this.label8.Text = "SEXO:";
            // 
            // TxtAltura
            // 
            this.TxtAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtAltura.Location = new System.Drawing.Point(18, 387);
            this.TxtAltura.Mask = "9.99";
            this.TxtAltura.Name = "TxtAltura";
            this.TxtAltura.Size = new System.Drawing.Size(519, 29);
            this.TxtAltura.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(15, 362);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(160, 18);
            this.label7.TabIndex = 12;
            this.label7.Text = "ALTURA (Metros):";
            // 
            // TxtPeso
            // 
            this.TxtPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPeso.Location = new System.Drawing.Point(18, 324);
            this.TxtPeso.Mask = "999.9";
            this.TxtPeso.Name = "TxtPeso";
            this.TxtPeso.Size = new System.Drawing.Size(519, 29);
            this.TxtPeso.TabIndex = 6;
            this.TxtPeso.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 299);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 18);
            this.label6.TabIndex = 10;
            this.label6.Text = "PESO (KG)";
            // 
            // TxtContato
            // 
            this.TxtContato.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtContato.Location = new System.Drawing.Point(18, 263);
            this.TxtContato.Mask = "(99)99999-9999";
            this.TxtContato.Name = "TxtContato";
            this.TxtContato.Size = new System.Drawing.Size(519, 29);
            this.TxtContato.TabIndex = 5;
            this.TxtContato.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 238);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(203, 18);
            this.label5.TabIndex = 8;
            this.label5.Text = "NÚMERO DO CONTATO:";
            // 
            // TxtDocumento
            // 
            this.TxtDocumento.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDocumento.Location = new System.Drawing.Point(17, 202);
            this.TxtDocumento.Mask = "999,999,999-99";
            this.TxtDocumento.Name = "TxtDocumento";
            this.TxtDocumento.Size = new System.Drawing.Size(519, 29);
            this.TxtDocumento.TabIndex = 4;
            this.TxtDocumento.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(229, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "NÚMERO DO DOCUMENTO:";
            // 
            // DtNascimento
            // 
            this.DtNascimento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DtNascimento.Location = new System.Drawing.Point(17, 152);
            this.DtNascimento.Name = "DtNascimento";
            this.DtNascimento.Size = new System.Drawing.Size(519, 20);
            this.DtNascimento.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(205, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "DATA DE NASCIMENTO:";
            // 
            // TxtNome
            // 
            this.TxtNome.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.TxtNome.Location = new System.Drawing.Point(14, 90);
            this.TxtNome.MaxLength = 45;
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(522, 29);
            this.TxtNome.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "NOME DO ALUNO:";
            // 
            // TxtMatricula
            // 
            this.TxtMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtMatricula.Location = new System.Drawing.Point(11, 29);
            this.TxtMatricula.Mask = "999999";
            this.TxtMatricula.Name = "TxtMatricula";
            this.TxtMatricula.Size = new System.Drawing.Size(526, 29);
            this.TxtMatricula.TabIndex = 1;
            this.TxtMatricula.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "NÚMERO DA MATRICULA:";
            // 
            // FormMatricula
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 477);
            this.Controls.Add(this.PnFicha);
            this.Controls.Add(this.PnLateral);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MinimizeBox = false;
            this.Name = "FormMatricula";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FICHA DE MATRICULA";
            this.Load += new System.EventHandler(this.FormMatricula_Load);
            this.PnLateral.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PbFoto)).EndInit();
            this.PnFicha.ResumeLayout(false);
            this.PnFicha.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PnLateral;
        private System.Windows.Forms.Button BtnFoto;
        private System.Windows.Forms.PictureBox PbFoto;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button BtnGravar;
        private System.Windows.Forms.Button BtnWebCam;
        private System.Windows.Forms.Panel PnFicha;
        private System.Windows.Forms.MaskedTextBox TxtMatricula;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker DtNascimento;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox TxtDocumento;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox TxtContato;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox TxtPeso;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox TxtAltura;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox CbSexo;
        private System.Windows.Forms.Label label8;
    }
}