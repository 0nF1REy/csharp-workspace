﻿using CONTROLE_ACADEMIA.modelo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;

namespace CONTROLE_ACADEMIA.visao
{
    public partial class FormMatricula : Form
    {
        public FormMatricula()
        {
            InitializeComponent();
        }

        public Aluno Reg { get; set; } // Comunicação com FormAcademia

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Reg = null;
            this.Dispose();
        }

        private void BtnGravar_Click(object sender, EventArgs e)
        {
            if (Reg == null) Novo();
            else Editar();
            this.Dispose();
        }


        private void Novo()
        {
            Reg = new Aluno()
            {
                ID = Int16.Parse(TxtMatricula.Text),
                Nome = TxtNome.Text,
                Contato = TxtContato.Text,
                Documento = TxtDocumento.Text,
                Nascimento = DtNascimento.Value.Date,
                Altura = Double.Parse(TxtAltura.Text),
                Peso = double.Parse(TxtPeso.Text.Replace(',', '.')),
                Sexo = CbSexo.Text.Substring(0, 1)
            };
        }

        private void Editar()
        {
            Reg.Nome = TxtNome.Text;
            Reg.Contato = TxtContato.Text;
            Reg.Documento = TxtDocumento.Text;
            Reg.Nascimento = DtNascimento.Value.Date;
            Reg.Altura = Double.Parse(TxtAltura.Text);
            Reg.Peso = double.Parse(TxtPeso.Text);
            Reg.Sexo = CbSexo.Text.Substring(0, 1);
        }

        private void FormMatricula_Load(object sender, EventArgs e)
        {
            if (Reg != null)
            {
                TxtMatricula.Text = Reg.ID.ToString();
                TxtMatricula.ReadOnly = true;
                TxtNome.Text = Reg.Nome;
                DtNascimento.Value = Reg.Nascimento;
                TxtDocumento.Text = Reg.Documento;
                TxtContato.Text = Reg.Contato;
                TxtAltura.Text = Reg.Altura.ToString();
                TxtPeso.Text = Reg.Peso.ToString();
                if (Reg.Sexo == "M") CbSexo.SelectedIndex = 0;
                if (Reg.Sexo == "F") CbSexo.SelectedIndex = 1;
                if (Reg.Sexo == "I") CbSexo.SelectedIndex = 2;
                BtnFoto.Enabled = true;
            }
            else BtnFoto.Enabled = false;
            CarregarFoto();
        }

        private void BtnFoto_Click(object sender, EventArgs e)
        {
            string caminho = $"\\fotos\\{TxtMatricula.Text}.png";
            if (Reg != null)
            {
                OpenFileDialog file = new OpenFileDialog();
                file.Filter = "Fotos|*.png";
                file.FileName = "";
                file.ShowDialog();
                if (File.Exists(Environment.CurrentDirectory +
                    caminho))
                {
                    Application.DoEvents(); // Processador AMD
                    PbFoto.Image.Dispose();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    File.Delete(Environment.CurrentDirectory + caminho);
                }
                File.Copy(file.FileName, Environment.CurrentDirectory + caminho);
                CarregarFoto();
            }
        }

        private void CarregarFoto()
        {
            string caminho = $"\\fotos\\{TxtMatricula.Text}.png";
            if (File.Exists(Environment.CurrentDirectory +
             caminho))
            {
                var fs = new FileStream(Environment.CurrentDirectory +
                caminho, FileMode.Open, FileAccess.Read);

                PbFoto.Image = Image.FromStream(fs);
            }
        }

        private void BtnWebCam_Click(object sender, EventArgs e)
        {
            FormWebCam camera = new FormWebCam();
            camera.caminho = Environment.CurrentDirectory +
                $"\\fotos\\{TxtMatricula.Text}.png";
            Application.DoEvents();
            if (PbFoto.Image != null) PbFoto.Image.Dispose();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            camera.ShowDialog();
            CarregarFoto();
        }
    }
}
