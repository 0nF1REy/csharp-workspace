﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video;
using AForge.Video.DirectShow;


namespace CONTROLE_ACADEMIA.visao
{
    public partial class FormWebCam : Form
    {
        public FormWebCam()
        {
            InitializeComponent();
        }

        private FilterInfoCollection VideoDevices;
        private VideoCaptureDevice VideoDevice;

        private void FormWebCam_Load(object sender, EventArgs e)
        {
            VideoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);

            foreach (FilterInfo dev in VideoDevices)
            {
                CbDevices.Items.Add(dev.Name);
            }
            if (CbDevices.Items.Count == 0)
            {
                BtnStart.Enabled = false;
                BtnFoto.Enabled = false;
            }
            CbDevices.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            VideoDevice = new VideoCaptureDevice(VideoDevices[CbDevices.SelectedIndex].MonikerString);
            VideoDevice.NewFrame += VideoDevice_NewFrame;
            VideoDevice.Start();
        }

        private void VideoDevice_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            Bitmap bitmap = (Bitmap)eventArgs.Frame.Clone();
            PbVideo.Image = bitmap;
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if(VideoDevice != null)
            {
                VideoDevice.Stop();
                Application.DoEvents();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            base.OnFormClosing(e);
        }

        private void BtnFoto_Click(object sender, EventArgs e)
        {
            PbFoto.Image = PbVideo.Image;
        }

        internal string caminho { get; set; }
        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            if (File.Exists(caminho))
            {
                Application.DoEvents();
                GC.Collect();
                GC.WaitForPendingFinalizers();
                File.Delete(caminho);
            }
            PbFoto.Image.Save(caminho);
            MessageBox.Show($"Foto salva em {caminho}");
            this.Dispose();
        }
    }
}
