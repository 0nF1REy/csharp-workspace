﻿namespace exercicio_ds
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textSubMensal2 = new TextBox();
            label4 = new Label();
            textHora302 = new TextBox();
            label5 = new Label();
            label3 = new Label();
            textHoraAtividade2 = new TextBox();
            label1 = new Label();
            textHA2 = new TextBox();
            groupBox2 = new GroupBox();
            textSubMensal1 = new TextBox();
            label2 = new Label();
            textHora301 = new TextBox();
            label6 = new Label();
            label7 = new Label();
            textHoraAtividade1 = new TextBox();
            label8 = new Label();
            textHA1 = new TextBox();
            groupBox3 = new GroupBox();
            textSubMensal3 = new TextBox();
            label9 = new Label();
            textHora303 = new TextBox();
            label10 = new Label();
            label11 = new Label();
            textHoraAtividade3 = new TextBox();
            label12 = new Label();
            textHA3 = new TextBox();
            btnCalcular = new Button();
            textSemanal = new TextBox();
            textTotalMensal = new TextBox();
            label13 = new Label();
            label14 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textSubMensal2);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(textHora302);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(textHoraAtividade2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(textHA2);
            groupBox1.Location = new Point(299, 82);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(237, 260);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "ETEC - Outra Unidade";
            // 
            // textSubMensal2
            // 
            textSubMensal2.Location = new Point(128, 215);
            textSubMensal2.Name = "textSubMensal2";
            textSubMensal2.ReadOnly = true;
            textSubMensal2.Size = new Size(100, 23);
            textSubMensal2.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 218);
            label4.Name = "label4";
            label4.Size = new Size(119, 15);
            label4.TabIndex = 8;
            label4.Text = "Subtotal Mensal x4,5:";
            // 
            // textHora302
            // 
            textHora302.Location = new Point(120, 168);
            textHora302.Name = "textHora302";
            textHora302.ReadOnly = true;
            textHora302.Size = new Size(100, 23);
            textHora302.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 176);
            label5.Name = "label5";
            label5.Size = new Size(99, 15);
            label5.TabIndex = 6;
            label5.Text = "Hora Aula + 30%:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 68);
            label3.Name = "label3";
            label3.Size = new Size(89, 15);
            label3.TabIndex = 3;
            label3.Text = "Hora Atividade:";
            // 
            // textHoraAtividade2
            // 
            textHoraAtividade2.Location = new Point(120, 60);
            textHoraAtividade2.Name = "textHoraAtividade2";
            textHoraAtividade2.ReadOnly = true;
            textHoraAtividade2.Size = new Size(100, 23);
            textHoraAtividade2.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 25);
            label1.Name = "label1";
            label1.Size = new Size(111, 15);
            label1.TabIndex = 1;
            label1.Text = "Hora Aula Semanal:";
            // 
            // textHA2
            // 
            textHA2.Location = new Point(120, 17);
            textHA2.Name = "textHA2";
            textHA2.PlaceholderText = "0";
            textHA2.Size = new Size(100, 23);
            textHA2.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textSubMensal1);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(textHora301);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(textHoraAtividade1);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(textHA1);
            groupBox2.Location = new Point(12, 82);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(281, 260);
            groupBox2.TabIndex = 10;
            groupBox2.TabStop = false;
            groupBox2.Text = "ETEC SEDE";
            // 
            // textSubMensal1
            // 
            textSubMensal1.Location = new Point(128, 215);
            textSubMensal1.Name = "textSubMensal1";
            textSubMensal1.ReadOnly = true;
            textSubMensal1.Size = new Size(100, 23);
            textSubMensal1.TabIndex = 9;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 218);
            label2.Name = "label2";
            label2.Size = new Size(119, 15);
            label2.TabIndex = 8;
            label2.Text = "Subtotal Mensal x4,5:";
            // 
            // textHora301
            // 
            textHora301.Location = new Point(120, 168);
            textHora301.Name = "textHora301";
            textHora301.ReadOnly = true;
            textHora301.Size = new Size(100, 23);
            textHora301.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 176);
            label6.Name = "label6";
            label6.Size = new Size(99, 15);
            label6.TabIndex = 6;
            label6.Text = "Hora Aula + 30%:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 68);
            label7.Name = "label7";
            label7.Size = new Size(89, 15);
            label7.TabIndex = 3;
            label7.Text = "Hora Atividade:";
            // 
            // textHoraAtividade1
            // 
            textHoraAtividade1.Location = new Point(120, 60);
            textHoraAtividade1.Name = "textHoraAtividade1";
            textHoraAtividade1.ReadOnly = true;
            textHoraAtividade1.Size = new Size(100, 23);
            textHoraAtividade1.TabIndex = 2;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 25);
            label8.Name = "label8";
            label8.Size = new Size(111, 15);
            label8.TabIndex = 1;
            label8.Text = "Hora Aula Semanal:";
            // 
            // textHA1
            // 
            textHA1.Location = new Point(120, 17);
            textHA1.Name = "textHA1";
            textHA1.PlaceholderText = "0";
            textHA1.Size = new Size(100, 23);
            textHA1.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(textSubMensal3);
            groupBox3.Controls.Add(label9);
            groupBox3.Controls.Add(textHora303);
            groupBox3.Controls.Add(label10);
            groupBox3.Controls.Add(label11);
            groupBox3.Controls.Add(textHoraAtividade3);
            groupBox3.Controls.Add(label12);
            groupBox3.Controls.Add(textHA3);
            groupBox3.Location = new Point(551, 82);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(237, 260);
            groupBox3.TabIndex = 10;
            groupBox3.TabStop = false;
            groupBox3.Text = "ETEC - Outra Unidade";
            // 
            // textSubMensal3
            // 
            textSubMensal3.Location = new Point(128, 215);
            textSubMensal3.Name = "textSubMensal3";
            textSubMensal3.ReadOnly = true;
            textSubMensal3.Size = new Size(100, 23);
            textSubMensal3.TabIndex = 9;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(6, 218);
            label9.Name = "label9";
            label9.Size = new Size(119, 15);
            label9.TabIndex = 8;
            label9.Text = "Subtotal Mensal x4,5:";
            // 
            // textHora303
            // 
            textHora303.Location = new Point(120, 168);
            textHora303.Name = "textHora303";
            textHora303.ReadOnly = true;
            textHora303.Size = new Size(100, 23);
            textHora303.TabIndex = 7;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(6, 176);
            label10.Name = "label10";
            label10.Size = new Size(99, 15);
            label10.TabIndex = 6;
            label10.Text = "Hora Aula + 30%:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(6, 68);
            label11.Name = "label11";
            label11.Size = new Size(89, 15);
            label11.TabIndex = 3;
            label11.Text = "Hora Atividade:";
            // 
            // textHoraAtividade3
            // 
            textHoraAtividade3.Location = new Point(120, 60);
            textHoraAtividade3.Name = "textHoraAtividade3";
            textHoraAtividade3.ReadOnly = true;
            textHoraAtividade3.Size = new Size(100, 23);
            textHoraAtividade3.TabIndex = 2;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(6, 25);
            label12.Name = "label12";
            label12.Size = new Size(111, 15);
            label12.TabIndex = 1;
            label12.Text = "Hora Aula Semanal:";
            // 
            // textHA3
            // 
            textHA3.Location = new Point(120, 17);
            textHA3.Name = "textHA3";
            textHA3.PlaceholderText = "0";
            textHA3.Size = new Size(100, 23);
            textHA3.TabIndex = 0;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(671, 383);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(117, 23);
            btnCalcular.TabIndex = 11;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // textSemanal
            // 
            textSemanal.Location = new Point(140, 361);
            textSemanal.Name = "textSemanal";
            textSemanal.ReadOnly = true;
            textSemanal.Size = new Size(100, 23);
            textSemanal.TabIndex = 10;
            // 
            // textTotalMensal
            // 
            textTotalMensal.Location = new Point(140, 403);
            textTotalMensal.Name = "textTotalMensal";
            textTotalMensal.ReadOnly = true;
            textTotalMensal.Size = new Size(100, 23);
            textTotalMensal.TabIndex = 12;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(18, 361);
            label13.Name = "label13";
            label13.Size = new Size(83, 15);
            label13.TabIndex = 10;
            label13.Text = "Total Semanal:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(18, 403);
            label14.Name = "label14";
            label14.Size = new Size(76, 15);
            label14.TabIndex = 13;
            label14.Text = "Total Mensal:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(textTotalMensal);
            Controls.Add(textSemanal);
            Controls.Add(btnCalcular);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private GroupBox groupBox1;
        private Label label1;
        private TextBox textHA2;
        private TextBox textHoraAtividade2;
        private Label label3;
        private TextBox textSubMensal2;
        private Label label4;
        private TextBox textHora302;
        private Label label5;
        private GroupBox groupBox2;
        private TextBox textSubMensal1;
        private Label label2;
        private TextBox textHora301;
        private Label label6;
        private Label label7;
        private TextBox textHoraAtividade1;
        private Label label8;
        private TextBox textHA1;
        private GroupBox groupBox3;
        private TextBox textSubMensal3;
        private Label label9;
        private TextBox textHora303;
        private Label label10;
        private Label label11;
        private TextBox textHoraAtividade3;
        private Label label12;
        private TextBox textHA3;
        private Button btnCalcular;
        private TextBox textSemanal;
        private TextBox textTotalMensal;
        private Label label13;
        private Label label14;
    }
}
