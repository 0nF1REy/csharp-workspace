﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_MATEMATICA
{
    public class ApiMatematica
    {
        public static bool IsPar (int n)
        {
            return n % 2 == 0 ? true : false;
        }

        public static bool Primo (int n)
        {
            // Divisivel por 1 e por ele mesmo
            if (n == 2) return true;
            if (IsPar(n)) return false;
            int cont = 0;
            for (int i = 1; i <= n; i++)
            {
                if (n % i == 0) cont++;
            }

            if (cont == 2) return true;

            return false;
        }
    }
}
