﻿using API_MATEMATICA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TESTE_CONSOLE
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Clear();
            Console.WriteLine("==================================================================");
            Console.WriteLine("TESTE DA BIBLIOTECA MATEMATICA - Realizado em: " + DateTime.Now);
            Console.WriteLine("--------------------------");
            Console.WriteLine("FUNÇÃO PRIMO");
            Console.WriteLine("----------------");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Cyan;
            int qtd = 0;
            TimeSpan calculo; 
            DateTime inicio = DateTime.Now;
            for (int i = 1; i < 65535; i++)
            {
                if (ApiMatematica.Primo(i))
                {
                    qtd++;
                    Console.WriteLine($"Primo {qtd} = {i}");
                }
            }
            DateTime fim = DateTime.Now;
            calculo = fim - inicio;
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("--------------------------");
            Console.WriteLine($"Tempo: {calculo.TotalSeconds} segundos");
            Console.Beep(1000, 500); 
            Thread.Sleep(500);
            Console.Beep(500, 500); 
        }
    }
}
