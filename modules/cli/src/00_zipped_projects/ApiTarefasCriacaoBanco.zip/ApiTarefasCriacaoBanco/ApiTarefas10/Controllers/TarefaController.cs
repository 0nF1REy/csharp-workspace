﻿using ApiTarefas10.Data;
using ApiTarefas10.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ApiTarefas10.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TarefaController : ControllerBase
    {
        private readonly AppDbContext _context;
        public TarefaController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> Criar(Tarefa tarefa)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Tarefas.Add(tarefa);
                    await _context.SaveChangesAsync();

                    return CreatedAtAction(nameof(ListarId), new { id = tarefa.Id }, tarefa);
                }
                else
                {
                    return BadRequest("Dados incorretos!");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            var tarefas = await _context.Tarefas.ToListAsync();
            return Ok(tarefas);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> ListarId(int id)
        {
            var tarefa = await _context.Tarefas.FindAsync(id);

            if (tarefa == null)
            {
                return NotFound();
            }

            return Ok(tarefa);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Deletar(int id)
        {
            try
            {
                var tarefa = await _context.Tarefas.FindAsync(id);

                if (tarefa == null)
                {
                    return NotFound();
                }

                _context.Tarefas.Remove(tarefa);
                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public async Task<IActionResult> Editar(Tarefa tarefa)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var tarefaEditar = await _context.Tarefas.FindAsync(tarefa.Id);

                    if (tarefaEditar == null)
                    {
                        return NotFound();
                    }

                    tarefaEditar.Status = tarefa.Status;
                    tarefaEditar.Prazo = tarefa.Prazo;
                    tarefaEditar.Prioridade = tarefa.Prioridade;
                    tarefaEditar.Responsavel = tarefa.Responsavel;
                    tarefaEditar.Finalizado = tarefa.Finalizado;
                    tarefaEditar.Descricao = tarefa.Descricao;

                    _context.Tarefas.Update(tarefaEditar);
                    await _context.SaveChangesAsync();

                    return NoContent();
                }
                else
                {
                    return BadRequest("Dados incorretos!");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
