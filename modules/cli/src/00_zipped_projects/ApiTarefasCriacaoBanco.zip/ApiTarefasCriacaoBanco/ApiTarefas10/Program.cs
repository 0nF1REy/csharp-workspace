using ApiTarefas10.Data;
using Microsoft.EntityFrameworkCore;
using Scalar.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddOpenApi();
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        new MySqlServerVersion(new Version(8, 0, 36))
    )
);

var app = builder.Build();

// Chame apenas uma vez, fora do if
app.MapScalarApiReference();
app.MapOpenApi();

if (app.Environment.IsDevelopment())
{
    Console.WriteLine("Scalar API mapeada!");
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();
